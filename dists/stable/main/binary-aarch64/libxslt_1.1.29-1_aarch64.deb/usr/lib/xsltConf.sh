#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/home/builder/.termux-build/out/usr/lib"
XSLT_LIBS="-lxslt  -L/home/builder/.termux-build/out/usr/lib -lxml2 -lz -L/home/builder/.termux-build/out/usr/lib -llzma -liconv -lm -lm "
XSLT_INCLUDEDIR="-I/home/builder/.termux-build/out/usr/include"
MODULE_VERSION="xslt-1.1.29"
