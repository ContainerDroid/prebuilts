#ifndef APTPKG_SHA256_H
#define APTPKG_SHA256_H

#include "sha2.h"

#warning "This header is deprecated, please include sha2.h instead"

#endif
