#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/home/builder/.termux-build/out/usr/lib"
XML2_LIBS="-lxml2 -lz -L/home/builder/.termux-build/out/usr/lib -llzma   -liconv  -lm "
XML2_INCLUDEDIR="-I/home/builder/.termux-build/out/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.4"

