.. cmake-module:: ../../Modules/FindOpenMP.cmake
