endfunction
-----------

Ends a list of commands in a function block.

::

  endfunction(expression)

See the :command:`function` command.
