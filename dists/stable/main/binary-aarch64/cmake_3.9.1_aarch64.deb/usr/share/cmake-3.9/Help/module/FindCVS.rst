.. cmake-module:: ../../Modules/FindCVS.cmake
