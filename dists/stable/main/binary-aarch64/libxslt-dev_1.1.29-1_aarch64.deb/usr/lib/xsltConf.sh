#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/lib"
XSLT_LIBS="-lxslt  -L/home/builder/termux-packages/out/rootfs/usr/lib -lxml2 -lz -llzma -liconv -lm -lm "
XSLT_INCLUDEDIR="-I/usr/include"
MODULE_VERSION="xslt-1.1.29"
