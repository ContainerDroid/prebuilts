#define GVPLUGIN_CONFIG_FILE "config6"
#define GVPLUGIN_VERSION 6
#define PACKAGE_BUGREPORT "http://www.graphviz.org/"
#define PACKAGE_NAME "graphviz"
#define PACKAGE_STRING "graphviz 2.40.1"
#define PACKAGE_TARNAME "graphviz"
#define PACKAGE_URL ""
#define PACKAGE_VERSION "2.40.1"
