rocks_trees = {
   { name = [[user]], root = home..[[/.luarocks]] },
   { name = [[system]], root = [[/home/builder/termux-packages/out/rootfs/usr]] }
}
